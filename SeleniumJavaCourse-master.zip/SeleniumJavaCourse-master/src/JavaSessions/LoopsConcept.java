package JavaSessions;

public class LoopsConcept {

	public static void main(String[] args) {

		
		//1. while:
		int i = 1; //Initialization
		while(i<=10){ //conditional 
			System.out.println(i);
			i++; //incremental/decremental
		}
		
		
		//2. for:
		for(int j=1; j<=10; j++){
			System.out.println(j);
		}
		
	}

}
