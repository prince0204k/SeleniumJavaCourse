package JavaSessions;

public class FinalKeyword {

	public static void main(String[] args) {

		final int wheels = 4;
		
		final int i = 10;
//		i = 20;
//		i = 30;
		
		System.out.println(i);
		
		
	}

}
